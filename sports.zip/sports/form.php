<?php
$insert=false;
if(isset($_POST['name'])){
  //Set connection variables
    $server="komalr.mysql.polardb.ap-south-1.rds.aliyuncs.com:3306";
    $username="komalrawatdb1";
    $password="Komal31@";
 
 //create database connection
 $con = mysqli_connect($server,$username,$password);
 
 
 //check for connection success
 if(!$con){
     die("connection to this database failed due to".mysqli_connect_error());
 }
//  echo"success connecting to the DB";
 
//collect post variables
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];
 
 
$sql= "  INSERT INTO `komalrawatdb1`.`form` (`name`, `email`, `password`) VALUES 
('$name', '$email', '$password');";
 
// echo $sql;
 
//execute query
if($con->query($sql)==true){
    // echo"Successfully inserted";
 
    //flag for successful insertion
    $insert=true;
}
else{
 
    echo"ERROR: $sql <br> $con->error";
}
 
//close the database connection
$con->close();
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  </head>

<body>
 
         <form action="form.php" method="post">
             <input type="text" name="name" id="name" placeholder="Enter your name">
             <input type="email" name="email" id="email" placeholder="Enter your email">
             <input type="text" name="password" id="password" placeholder="Enter your password">
 
            </textarea>
             <button class="btn">Submit</button>
 
         </form>
 
 </body>
 
 </html>